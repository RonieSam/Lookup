Place your PNG/JPG figures and diagrams in this folder.
